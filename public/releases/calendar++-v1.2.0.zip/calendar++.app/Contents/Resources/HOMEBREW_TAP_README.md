# den-kim's Homebrew Tap

Homebrew tap for calendar++ and other macOS applications.

## Installation

### Add the tap

```bash
brew tap den-kim/tap
```

## Available Casks

### calendar-plus-plus

Smart calendar menu bar app for macOS with focus modes and deep work support.

```bash
brew install --cask calendar-plus-plus
```

**Features:**
- 📅 Menu bar calendar with quick event access
- 🎯 Focus modes (Work/Personal/All calendars)
- ⏱️ Deep work timer and productivity tracking
- 🔗 URL scheme automation (`calendarplusplus://`)
- ✅ Unified reminders and events timeline
- 🚀 Shortcuts app integration

**Requirements:**
- macOS 13.0 or later
- Calendar and Reminders permissions

**Repository:** [github.com/den-kim/calendarplusplus](https://github.com/den-kim/calendarplusplus)

## Updating

```bash
brew update
brew upgrade --cask calendar-plus-plus
```

## Uninstalling

```bash
brew uninstall --cask calendar-plus-plus
```

To remove all app data:
```bash
brew uninstall --zap --cask calendar-plus-plus
```

## Support

For issues or feature requests, please visit:
- [GitHub Issues](https://github.com/den-kim/calendarplusplus/issues)
- [Discussions](https://github.com/den-kim/calendarplusplus/discussions)
